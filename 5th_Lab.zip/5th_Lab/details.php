<?php
	include "connection.php";

	$id = $_GET['id'];

	$query = "select * from users where id=$id";

	$result = mysqli_query($con, $query);

	// mysqli_query($con, $query);

	while ( $row = mysqli_fetch_array($result)) {
		echo "Name : ".$row['name']; echo "<br>";
		echo "Email : ".$row['email']; echo "<br>";
		echo "Mobile_no : ".$row['mobile_no']; echo "<br>";
		echo "Password : ".$row['password']; echo "<br>";
	}
?>