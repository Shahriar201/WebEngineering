<?php
	include "connection.php";

	$query = "select * from users";
	$result = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Dara Show</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>
	<h1 class="text-center btn-primary">Show All Information</h1>

	<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Mobile Number</th>
      <th scope="col">Password</th>
      <th scope="col">Details</th>
    </tr>
  </thead>
  <tbody>
    <?php
    	while ($row = mysqli_fetch_array($result)) {
    		echo "<tr>";

    			echo "<td>".$row['id']."</td>";
    			echo "<td>".$row['name']."</td>";
    			echo "<td>".$row['email']."</td>";
    			echo "<td>".$row['mobile_no']."</td>";
    			echo "<td>".$row['password']."</td>";

    			echo '<td><a href="details.php?id='.$row['id'].'" class="btn btn-success">Details</a></td>';

    		echo "</tr>";
    	}
    ?>
  </tbody>
</table>

</body>
</html>