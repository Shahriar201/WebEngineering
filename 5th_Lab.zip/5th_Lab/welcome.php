<?php

	include "connection.php";
	
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile_no'];
	$password = $_POST['password'];

	$sql = "INSERT INTO users (name, email, mobile_no, password) VALUES ('$name', '$email', '$mobile', '$password')";

  mysqli_query($con, $sql);

?>