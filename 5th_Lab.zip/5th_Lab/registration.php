<?php
	
	echo '
	<form action="welcome.php" method="post">
	
	Name: <input type="text" name="name"><br><br>

	E-mail: <input type="text" name="email"><br><br>

	Mobile No: <input type = "number" name="mobile_no"><br><br>

	Password: <input type="password" name="password"><br><br>

	<input type="submit">
	</form>';
?>