<?php
	$name = $_POST['name'];
	$age = $_POST['age'];
	$email = $_POST['email'];
	$gender = $_POST['gender'];

	echo "Name: ".$name;
	echo "<br>";
	echo "Age: ".$age;
	echo "<br>";
	echo "Email: ".$email;
	echo "<br>";
	echo "Gender: ".$gender;
	?>
